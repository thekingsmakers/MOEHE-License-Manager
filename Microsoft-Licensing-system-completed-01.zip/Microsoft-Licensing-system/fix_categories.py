
import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

async def fix_categories():
    load_dotenv('backend/.env')
    mongo_url = os.getenv('MONGO_URL')
    db_name = os.getenv('DB_NAME', 'service_renewal_hub')
    
    if not mongo_url:
        print("MONGO_URL not found in .env")
        return

    print(f"Connecting to {mongo_url}, DB: {db_name}")
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    # Get current admin
    admin = await db.users.find_one({"role": "admin"})
    if not admin:
        print("No admin user found to assign categories to.")
        return
    
    admin_id = admin["id"]
    print(f"Admin found: {admin['email']} (ID: {admin_id})")
    
    # Find all categories not belonging to this admin
    orphaned = await db.categories.find({"user_id": {"$ne": admin_id}}).to_list(None)
    print(f"Found {len(orphaned)} orphaned or misassigned categories.")
    
    for cat in orphaned:
        old_user_id = cat.get('user_id')
        print(f"Re-assigning category '{cat['name']}' from {old_user_id} to {admin_id}")
        await db.categories.update_one({"id": cat["id"]}, {"$set": {"user_id": admin_id}})
    
    print("\nCategory re-assignment complete.")
    client.close()

if __name__ == "__main__":
    asyncio.run(fix_categories())
