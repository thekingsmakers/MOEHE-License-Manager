
import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

async def check_db():
    load_dotenv('backend/.env')
    mongo_url = os.getenv('MONGO_URL', 'mongodb://localhost:27017')
    db_name = os.getenv('DB_NAME', 'service_renewal_hub')
    
    print(f"Connecting to {mongo_url}, DB: {db_name}")
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    logs = await db.notification_logs.find().sort("sent_at", -1).to_list(10)
    print(f"Recent logs: {len(logs)}")
    for l in logs:
        print(f"Log: {l.get('service_name')} to {l.get('recipient_email')} Status: {l.get('status')} Type: {l.get('type')}")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(check_db())
