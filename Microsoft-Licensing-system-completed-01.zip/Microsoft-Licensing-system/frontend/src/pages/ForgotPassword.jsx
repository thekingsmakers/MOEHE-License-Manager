import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Loader2, ArrowLeft, Mail, CheckCircle } from "lucide-react";
import axios from 'axios';
import { API } from "../App";
import { toast } from "sonner";

const ForgotPassword = () => {
    const [email, setEmail] = useState('');
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await axios.post(`${API}/auth/forgot-password`, { email });
            setSuccess(true);
            toast.success("Reset code sent! Check your email.");
            // Wait a moment then redirect to reset page
            setTimeout(() => {
                navigate('/reset-password', { state: { email } });
            }, 2000);
        } catch (err) {
            console.error(err);
            toast.error("Failed to send code. Please try again.");
            // Even on error, sometimes we want to show success for security, but here we'll just show error
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex min-h-screen items-center justify-center p-4 bg-muted/20">
            <div className="w-full max-w-sm space-y-6 bg-card p-6 rounded-lg shadow-lg border border-border">
                <div className="space-y-2 text-center">
                    <h1 className="text-2xl font-bold tracking-tight">Forgot password?</h1>
                    <p className="text-sm text-muted-foreground">
                        Enter your email address to receive a secure reset code.
                    </p>
                </div>

                {success ? (
                    <div className="text-center space-y-4 py-4">
                        <CheckCircle className="h-12 w-12 text-primary mx-auto" />
                        <p>If an account exists for <strong>{email}</strong>, you will receive an email shortly.</p>
                        <Button
                            className="w-full btn-primary"
                            onClick={() => navigate('/reset-password', { state: { email } })}
                        >
                            Enter Reset Code
                        </Button>
                    </div>
                ) : (
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="email">Email Address</Label>
                            <div className="relative">
                                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                <Input
                                    id="email"
                                    type="email"
                                    placeholder="name@example.com"
                                    className="pl-9 bg-background"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                />
                            </div>
                        </div>

                        <Button type="submit" className="w-full btn-primary" disabled={loading}>
                            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                            Send Reset Code
                        </Button>
                    </form>
                )}

                <div className="text-center">
                    <Link to="/login" className="text-sm font-medium text-primary hover:underline flex items-center justify-center gap-1">
                        <ArrowLeft className="h-4 w-4" /> Back to Login
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default ForgotPassword;
