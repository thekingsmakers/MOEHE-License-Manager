# Service Renewal Hub - Production Setup Guide

This guide details the complete installation and setup process for deploying the **Service Renewal Hub** in a Windows production environment.

## 🏗️ System Architecture

- **Frontend**: React (served via Nginx)
- **Backend**: Python FastAPI (running on port 8003)
- **Web Server**: Nginx (Reverse Proxy & SSL Termination)
- **Database**: MongoDB
- **Automation**: Windows Batch Scripts (`restart_system.bat`)

---

## 1. Prerequisites

Ensure the following are installed on the server:

1.  **Python 3.9+**: [Download](https://www.python.org/downloads/) (Ensure "Add Python to PATH" is checked during installation)
2.  **Node.js (LTS)**: [Download](https://nodejs.org/)
3.  **Nginx**: [Download](https://nginx.org/en/download.html) (Unzip to root folder, e.g., `nginx-1.28.1`)
4.  **MongoDB**: [Download](https://www.mongodb.com/try/download/community) (Or use MongoDB Atlas connection string)

---

## 2. Directory Structure

Ensure your project folder looks like this:

```text
Microsoft-Licensing-system/
├── backend/                # Python API code
├── frontend/               # React source code
├── nginx-1.28.1/           # Nginx server files
├── Certs/                  # SSL Certificates
│   ├── Certificate.crt     # Public Certificate
│   └── Private.key         # Private Key
├── restart_system.bat      # Startup Script
├── CleanMigration.bat      # Cleanup Script
└── README.md
```

> **Important**: The `Certs` folder must contain your valid SSL certificate and key named exactly `Certificate.crt` and `Private.key`.

---

## 3. Configuration

### Backend Environment
Edit `backend/.env`:

```ini
MONGO_URL="mongodb://localhost:27017"
DB_NAME="service_renewal_hub"
JWT_SECRET="<generate-secure-random-string>"
CORS_ORIGINS="*"
# Email Settings (Optional, can be set in UI)
SENDER_EMAIL="notifications@yourdomain.com"
```

### Frontend Environment
Edit `frontend/.env`:
```ini
# Production URL (auto-detected by app, but good to set)
REACT_APP_BACKEND_URL=https://license.thekingsmaker.org
```

### Nginx Configuration
Ensure `nginx-1.28.1/conf/nginx.conf` is configured to:
1.  Listen on port **80** (HTTP) and **443** (HTTPS).
2.  Point `ssl_certificate` to `../../Certs/Certificate.crt`.
3.  Proxy `/api` requests to `http://127.0.0.1:8003`.

---

## 4. 🚀 Starting the Application

We have automated the startup process. You do **not** need to manually run Python or Node commands.

### Run `restart_system.bat`

Double-click this script to:
1.  **Stop** any running instances of Nginx or Python.
2.  **Build** the Frontend automatically (`npm run build`).
3.  **Install** any missing Python dependencies.
4.  **Start** the Backend API (background process).
5.  **Start** Nginx.

Once the script says **"System is live!"**, access the site at:
👉 **https://license.thekingsmaker.org**

---

## 5. 📦 Migration & Cleanup

If you need to move the project to another server or zip it for transfer, use the cleanup script to remove temporary files and huge node_modules folders.

### Run `CleanMigration.bat`

Double-click this script to **DELETE**:
- `frontend/node_modules`
- `frontend/build`
- All Python `__pycache__` files

> **Note**: The next time you run `restart_system.bat`, it will take longer as it re-installs dependencies and re-builds the frontend.

---

## 6. 🌐 External Access & Cloudflare

If accessing this application from outside the local network via **Cloudflare Tunnel**, you may encounter **403 Forbidden** errors on API calls.

### The Fix: Disable "Bot Fight Mode"

1.  Log in to your **Cloudflare Dashboard**.
2.  Navigate to **Security > Bots**.
3.  Find **"Bot Fight Mode"** or **"Super Bot Fight Mode"**.
4.  Turn it **OFF** (or set to "Allow").

*Reason: Cloudflare's JS challenges block the automated API calls made by the React frontend.*

---

## 7. Troubleshooting

### ❌ Site Not Reachable
- Check if Nginx is running: Open Task Manager, look for `nginx.exe`.
- Check `nginx-1.28.1/logs/error.log`.

### ❌ "500 Internal Server Error" on Nginx
- Run `restart_system.bat` again to ensure the Frontend Build exists.
- This error usually means the `frontend/build` folder is missing.

### ❌ "Mixed Content" Errors
- Ensure you are accessing the site via **https://**.
- Ensure `restart_system.bat` was used to start the backend (it sets the correct ports).

### ❌ Notifications Not Sending
- Go to **Admin > Settings > Email**.
- Verify your SMTP credentials or Resend API Key.
- Click "Send Test Email".
- Check `backend/debug_email.log` for detailed error messages (e.g., SSL verification issues).
