
import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
from datetime import datetime, timezone
import uuid

async def fix_and_verify():
    load_dotenv('backend/.env')
    mongo_url = os.getenv('MONGO_URL')
    db_name = os.getenv('DB_NAME', 'service_renewal_hub')
    
    if not mongo_url:
        print("MONGO_URL not found in .env")
        return

    print(f"Connecting to {mongo_url}, DB: {db_name}")
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    # 1. Fix Typos
    print("Checking for email typos in service owners...")
    services = await db.services.find({"owners.email": {"$regex": "gmai.com$"}}).to_list(100)
    
    if not services:
        print("No typos found.")
    else:
        for s in services:
            print(f"Fixing typos in Service: {s.get('name')} (ID: {s.get('id')})")
            owners = s.get('owners', [])
            updated = False
            for owner in owners:
                if owner.get('email', '').endswith('gmai.com'):
                    old_email = owner['email']
                    new_email = old_email.replace('gmai.com', 'gmail.com')
                    print(f"  Correcting {old_email} -> {new_email}")
                    owner['email'] = new_email
                    updated = True
            
            if updated:
                await db.services.update_one({"id": s['id']}, {"$set": {"owners": owners}})
                print(f"  Service {s['name']} updated.")

    # 2. Check Notification Logs for recent manual reminder
    print("\nChecking recent notification logs...")
    logs = await db.notification_logs.find().sort("sent_at", -1).to_list(5)
    for l in logs:
        print(f"Log: {l.get('service_name')} | Recipient: {l.get('recipient_email')} | Status: {l.get('status')} | Type: {l.get('type')} | Date: {l.get('sent_at')}")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(fix_and_verify())
