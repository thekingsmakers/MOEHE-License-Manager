import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

# Path to .env
env_path = os.path.join(os.path.dirname(__file__), '.env')
load_dotenv(env_path)

async def diagnose():
    mongo_url = os.getenv('MONGO_URL')
    db_name = os.getenv('DB_NAME')
    
    print(f"--- Diagnostic Report ---")
    print(f"Target URL: {mongo_url}")
    print(f"Target DB: {db_name}")
    
    if not mongo_url:
        print("ERROR: MONGO_URL is empty!")
        return

    try:
        client = AsyncIOMotorClient(mongo_url, serverSelectionTimeoutMS=5000)
        # Force connection
        await client.server_info()
        print("✅ Connection: SUCCESS")
        
        db = client[db_name]
        
        # Check Services
        count = await db.services.count_documents({})
        print(f"✅ Services Found: {count}")
        
        if count > 0:
            sample = await db.services.find_one({})
            print(f"   Sample Service: {sample.get('name')}")
        else:
            print("⚠️ WARNING: Database connected but 'services' collection is empty.")
            
    except Exception as e:
        print(f"❌ Connection: FAILED")
        print(f"   Error: {e}")

if __name__ == "__main__":
    asyncio.run(diagnose())
