import asyncio
import os
import io
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
import pandas as pd
from reports import get_services_df, generate_pdf

# Setup
env_path = os.path.join(os.path.dirname(__file__), '.env')
load_dotenv(env_path)

async def debug_export():
    mongo_url = os.getenv('MONGO_URL')
    db_name = os.getenv('DB_NAME')
    
    print(f"Connecting to {db_name}...")
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    # 1. Fetch Real Data
    services = await db.services.find().to_list(1000)
    print(f"Fetched {len(services)} services.")
    
    # 2. Test DataFrame Conversion
    print("\n--- Testing DataFrame Conversion ---")
    try:
        df = get_services_df(services)
        print("✅ DataFrame created successfully.")
        print(df.head())
        print(df.info())
    except Exception as e:
        print(f"❌ DataFrame Conversion Failed: {e}")
        import traceback
        traceback.print_exc()
        return

    # 3. Test PDF Generation
    print("\n--- Testing PDF Generation ---")
    try:
        pdf_stream = generate_pdf(df)
        print(f"✅ PDF Generated. Size: {pdf_stream.getbuffer().nbytes} bytes")
    except Exception as e:
        print(f"❌ PDF Generation Failed: {e}")
        import traceback
        traceback.print_exc()

    # 4. Test Excel Generation
    print("\n--- Testing Excel Generation ---")
    try:
        stream = io.BytesIO()
        with pd.ExcelWriter(stream, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name="Services")
        print(f"✅ Excel Generated. Size: {stream.getbuffer().nbytes} bytes")
    except Exception as e:
        print(f"❌ Excel Generation Failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    try:
        asyncio.run(debug_export())
    except Exception as e:
        print(f"Critical Sript Error: {e}")
