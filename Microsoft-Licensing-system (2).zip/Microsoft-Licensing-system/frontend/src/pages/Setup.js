import React, { useState } from 'react';
import axios from 'axios';
import { API } from '../App';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export default function Setup() {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        mongo_url: 'mongodb://localhost:27017',
        db_name: 'service_renewal_hub',
        admin_name: '',
        admin_email: '',
        admin_password: ''
    });

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await axios.post(`${API}/setup`, formData);
            toast.success('Setup completed successfully!');
            navigate('/login');
            window.location.reload(); // Reload to clear setup state
        } catch (error) {
            toast.error(error.response?.data?.detail || 'Setup failed');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
            <div className="w-full max-w-md space-y-8">
                <div className="text-center">
                    <h1 className="text-3xl font-bold text-primary">Service Renewal Hub</h1>
                    <p className="mt-2 text-muted-foreground">Initial System Setup</p>
                </div>

                <div className="bg-card border border-border rounded-lg p-6 shadow-lg">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="space-y-4">
                            <h2 className="text-lg font-semibold text-foreground">Database Configuration</h2>
                            <div className="space-y-2">
                                <label className="text-sm font-medium text-foreground">MongoDB URL</label>
                                <input
                                    type="text"
                                    required
                                    className="w-full px-3 py-2 bg-background border border-border rounded-md text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                                    value={formData.mongo_url}
                                    onChange={(e) => setFormData({ ...formData, mongo_url: e.target.value })}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-sm font-medium text-foreground">Database Name</label>
                                <input
                                    type="text"
                                    required
                                    className="w-full px-3 py-2 bg-background border border-border rounded-md text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                                    value={formData.db_name}
                                    onChange={(e) => setFormData({ ...formData, db_name: e.target.value })}
                                />
                            </div>
                        </div>

                        <div className="space-y-4 border-t border-border pt-4">
                            <h2 className="text-lg font-semibold text-foreground">Admin Account</h2>
                            <div className="space-y-2">
                                <label className="text-sm font-medium text-foreground">Full Name</label>
                                <input
                                    type="text"
                                    required
                                    className="w-full px-3 py-2 bg-background border border-border rounded-md text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                                    value={formData.admin_name}
                                    onChange={(e) => setFormData({ ...formData, admin_name: e.target.value })}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-sm font-medium text-foreground">Email Address</label>
                                <input
                                    type="email"
                                    required
                                    className="w-full px-3 py-2 bg-background border border-border rounded-md text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                                    value={formData.admin_email}
                                    onChange={(e) => setFormData({ ...formData, admin_email: e.target.value })}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-sm font-medium text-foreground">Password</label>
                                <input
                                    type="password"
                                    required
                                    className="w-full px-3 py-2 bg-background border border-border rounded-md text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                                    value={formData.admin_password}
                                    onChange={(e) => setFormData({ ...formData, admin_password: e.target.value })}
                                />
                            </div>
                        </div>

                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full py-2 px-4 bg-primary text-primary-foreground font-semibold rounded-md hover:opacity-90 transition disabled:opacity-50"
                        >
                            {loading ? 'Setting up...' : 'Complete Setup'}
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
}
