import React, { useState, useEffect } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Loader2, ArrowLeft, Key, Lock, Mail } from "lucide-react";
import axios from 'axios';
import { toast } from "sonner";

const ResetPassword = () => {
    const location = useLocation();
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        email: '',
        code: '',
        new_password: '',
        confirm_password: ''
    });
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        // Pre-fill email if passed from previous page
        if (location.state?.email) {
            setFormData(prev => ({ ...prev, email: location.state.email }));
        }
    }, [location.state]);

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (formData.new_password !== formData.confirm_password) {
            toast.error("Passwords do not match");
            return;
        }

        if (formData.new_password.length < 6) {
            toast.error("Password must be at least 6 characters");
            return;
        }

        setLoading(true);
        try {
            await axios.post(`${process.env.REACT_APP_BACKEND_URL}/api/auth/reset-password`, {
                email: formData.email,
                code: formData.code,
                new_password: formData.new_password
            });

            toast.success("Password reset successfully! Please login.");
            navigate('/login');
        } catch (err) {
            console.error(err);
            toast.error(err.response?.data?.detail || "Failed to reset password. Check your code.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex min-h-screen items-center justify-center p-4 bg-muted/20">
            <div className="w-full max-w-sm space-y-6 bg-card p-6 rounded-lg shadow-lg border border-border">
                <div className="space-y-2 text-center">
                    <h1 className="text-2xl font-bold tracking-tight">Set new password</h1>
                    <p className="text-sm text-muted-foreground">
                        Enter your 6-digit code and new password.
                    </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        <div className="relative">
                            <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input
                                id="email"
                                type="email"
                                placeholder="name@example.com"
                                className="pl-9 bg-background"
                                value={formData.email}
                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                required
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="code">Reset Code</Label>
                        <div className="relative">
                            <Key className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input
                                id="code"
                                type="text"
                                placeholder="123456"
                                className="pl-9 bg-background font-mono tracking-widest"
                                value={formData.code}
                                onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                                required
                                maxLength={6}
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="new_password">New Password</Label>
                        <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input
                                id="new_password"
                                type="password"
                                placeholder="••••••••"
                                className="pl-9 bg-background"
                                value={formData.new_password}
                                onChange={(e) => setFormData({ ...formData, new_password: e.target.value })}
                                required
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="confirm_password">Confirm Password</Label>
                        <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input
                                id="confirm_password"
                                type="password"
                                placeholder="••••••••"
                                className="pl-9 bg-background"
                                value={formData.confirm_password}
                                onChange={(e) => setFormData({ ...formData, confirm_password: e.target.value })}
                                required
                            />
                        </div>
                    </div>

                    <Button type="submit" className="w-full btn-primary" disabled={loading}>
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                        Reset Password
                    </Button>
                </form>

                <div className="text-center">
                    <Link to="/login" className="text-sm font-medium text-primary hover:underline flex items-center justify-center gap-1">
                        <ArrowLeft className="h-4 w-4" /> Back to Login
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default ResetPassword;
