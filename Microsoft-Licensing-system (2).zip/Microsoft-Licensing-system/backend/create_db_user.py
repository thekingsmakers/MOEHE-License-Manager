import os
import sys
import pymongo
from pymongo import MongoClient

def create_db_user():
    print("==========================================")
    print("   MongoDB Database & User Creator")
    print("==========================================")
    print("")
    
    # Defaults
    default_host = "localhost"
    default_port = "27017"
    
    # Get Inputs
    mongo_host = input(f"MongoDB Host [{default_host}]: ").strip() or default_host
    mongo_port = input(f"MongoDB Port [{default_port}]: ").strip() or default_port
    
    # Construct connection string (initially without auth)
    # If the DB already requires auth, you'd need admin creds here, but usually this is for fresh setup
    # or connecting to the admin DB to create users.
    client_uri = input("Enter Connection String (Press Enter to use 'mongodb://localhost:27017'): ").strip()
    
    if not client_uri:
        client_uri = f"mongodb://{mongo_host}:{mongo_port}"
        
    print(f"\nConnecting to: {client_uri} ...")
    
    try:
        client = MongoClient(client_uri, serverSelectionTimeoutMS=5000)
        # Force connection verify
        client.server_info()
        print("Successfully connected to MongoDB!")
    except Exception as e:
        print(f"\n[ERROR] Could not connect to MongoDB: {e}")
        print("Please ensure MongoDB is running.")
        return

    print("\n------------------------------------------")
    db_name = input("Target Database Name [service_renewal_hub]: ").strip() or "service_renewal_hub"
    username = input("New User Username: ").strip()
    if not username:
        print("[ERROR] Username is required.")
        return
    password = input("New User Password: ").strip()
    if not password:
        print("[ERROR] Password is required.")
        return
        
    db = client[db_name]
    
    print(f"\nCreating user '{username}' on database '{db_name}'...")
    
    try:
        # Create user with readWrite and dbAdmin roles on the specific DB
        db.command(
            "createUser", username,
            pwd=password,
            roles=[
                {"role": "readWrite", "db": db_name},
                {"role": "dbAdmin", "db": db_name}
            ]
        )
        print(f"\n[SUCCESS] User '{username}' created successfully!")
        
        # Insert a dummy document to ensuring the DB is actually created/persisted if it didn't exist
        if db_name not in client.list_database_names():
            print("Initializing database collection...")
            db.init_check.insert_one({"status": "initialized", "created_at": "now"})
            
        print("\n==========================================")
        print("Updated Connection String for your .env:")
        print(f"MONGO_URL=\"mongodb://{username}:{password}@{mongo_host}:{mongo_port}/{db_name}\"")
        print(f"DB_NAME=\"{db_name}\"")
        print("==========================================")
        
    except pymongo.errors.OperationFailure as e:
        if "already exists" in str(e):
             print(f"\n[ERROR] User '{username}' already exists on database '{db_name}'.")
             print("You can update the password using db.changeUserPassword() in mongosh.")
        else:
            print(f"\n[ERROR] Failed to create user: {e}")
    except Exception as e:
        print(f"\n[ERROR] An unexpected error occurred: {e}")

if __name__ == "__main__":
    try:
        # Check if pymongo is installed
        import pymongo
        create_db_user()
    except ImportError:
        print("Error: 'pymongo' library is missing.")
        print("Please run this script within the backend virtual environment.")
        print("Try running 'CreateDBUser.bat' instead.")
    input("\nPress Enter to exit...")
