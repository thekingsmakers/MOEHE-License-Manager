
import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

async def check_service():
    load_dotenv('backend/.env')
    mongo_url = os.getenv('MONGO_URL')
    db_name = os.getenv('DB_NAME', 'service_renewal_hub')
    
    if not mongo_url:
        print("MONGO_URL not found in .env")
        return

    print(f"Connecting to {mongo_url}, DB: {db_name}")
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    service = await db.services.find_one({"name": "Dell contract"})
    if service:
        print(f"Service Found: {service.get('name')}")
        print(f"Owners: {service.get('owners')}")
        print(f"Full Service Doc: {service}")
    else:
        print("Dell contract not found")

    client.close()

if __name__ == "__main__":
    asyncio.run(check_service())
