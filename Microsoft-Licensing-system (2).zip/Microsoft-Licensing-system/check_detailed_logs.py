
import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
from datetime import datetime, timezone

async def check_logs():
    load_dotenv('backend/.env')
    mongo_url = os.getenv('MONGO_URL')
    db_name = os.getenv('DB_NAME', 'service_renewal_hub')
    
    if not mongo_url:
        print("MONGO_URL not found in .env")
        return

    print(f"Connecting to {mongo_url}, DB: {db_name}")
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    print("\n--- Recent Notification Logs ---")
    logs = await db.notification_logs.find().sort("sent_at", -1).to_list(10)
    for l in logs:
        print(f"[{l.get('sent_at')}] Service: {l.get('service_name')} | Recipient: {l.get('recipient_email')} | Status: {l.get('status')} | Type: {l.get('type')}")
    
    print("\n--- Recent Email Logs (if any) ---")
    try:
        e_logs = await db.email_logs.find().sort("sent_at", -1).to_list(10)
        for el in e_logs:
            print(f"[{el.get('sent_at')}] To: {el.get('to')} | Subject: {el.get('subject')} | Result: {el.get('result')}")
    except:
        print("No email_logs collection found or error reading it.")

    client.close()

if __name__ == "__main__":
    asyncio.run(check_logs())
