import sys
import os
import io
import pandas as pd
from datetime import datetime, timedelta

# Add backend folder to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from reports import get_services_df, generate_pdf

def test_reports():
    print("Testing Report Generation...")
    
    # Dummy Data
    services = [
        {
            "name": "Service A",
            "provider": "Provider X",
            "category_name": "Dev Tools",
            "cost": 100.0,
            "expiry_date": (datetime.now() + timedelta(days=30)).isoformat(),
            "status": "active",
            "contact_email": "admin@example.com"
        },
        {
            "name": "Service B",
            "provider": "Provider Y",
            "category_name": "Office",
            "cost": 50.0,
            "expiry_date": (datetime.now() - timedelta(days=5)).isoformat(),
            "status": "expired",
            "contact_email": "user@example.com"
        }
    ]
    
    # Test DataFrame
    df = get_services_df(services)
    print(f"DataFrame Created. Shape: {df.shape}")
    print(df.head())
    
    # Test PDF
    try:
        pdf_stream = generate_pdf(df)
        pdf_size = pdf_stream.getbuffer().nbytes
        print(f"PDF Generated. Size: {pdf_size} bytes")
        if pdf_size < 100:
            print("ERROR: PDF too small")
            exit(1)
    except Exception as e:
        print(f"ERROR generating PDF: {e}")
        exit(1)

    # Test Excel
    try:
        stream = io.BytesIO()
        with pd.ExcelWriter(stream, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name="Services")
        excel_size = stream.getbuffer().nbytes
        print(f"Excel Generated. Size: {excel_size} bytes")
    except Exception as e:
        print(f"ERROR generating Excel: {e}")
        exit(1)

    print("ALL TESTS PASSED")

if __name__ == "__main__":
    test_reports()
