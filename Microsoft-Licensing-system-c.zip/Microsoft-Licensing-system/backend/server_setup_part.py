from fastapi import FastAPI, APIRouter, HTTPException, Depends, BackgroundTasks
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
import logging
import asyncio
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr, ConfigDict
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import jwt
import bcrypt
import resend

# ==================== CONFIGURATION ====================

ROOT_DIR = Path(__file__).parent
ENV_PATH = ROOT_DIR / '.env'
load_dotenv(ENV_PATH)

# Global variables for lazy connection
mongo_client: Optional[AsyncIOMotorClient] = None
db = None

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# JWT configuration
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key-change-in-production')
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 24

# Create the main app
app = FastAPI(title="Service Renewal Hub")

origins = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

security = HTTPBearer()

# ==================== DATABASE HELPERS ====================

async def connect_db():
    global mongo_client, db
    mongo_url = os.environ.get('MONGO_URL')
    db_name = os.environ.get('DB_NAME')
    
    if not mongo_url or not db_name:
        logger.warning("Database configuration missing")
        return False

    try:
        mongo_client = AsyncIOMotorClient(mongo_url, serverSelectionTimeoutMS=5000)
        # Verify connection
        await mongo_client.server_info()
        db = mongo_client[db_name]
        logger.info(f"Connected to MongoDB: {db_name}")
        return True
    except Exception as e:
        logger.error(f"Failed to connect to MongoDB: {e}")
        mongo_client = None
        db = None
        return False

@app.on_event("startup")
async def startup_db_client():
    await connect_db()

@app.on_event("shutdown")
async def shutdown_db_client():
    global mongo_client
    if mongo_client:
        mongo_client.close()

# Middleware to check DB connection (except for setup endpoints)
async def check_db_connection():
    if db is None:
        raise HTTPException(status_code=503, detail="Database not connected. Please complete setup.")

# ==================== SETUP ENDPOINTS ====================

class SetupData(BaseModel):
    mongo_url: str
    db_name: str
    admin_name: str
    admin_email: EmailStr
    admin_password: str

@api_router.get("/status")
async def get_system_status():
    global db
    if db is None:
        # Try to connect if config exists but connection failed previously
        if os.environ.get('MONGO_URL'):
            if await connect_db():
                return {"status": "ok", "message": "System operational"}
            else:
                return {"status": "db_error", "message": "Cannot connect to database"}
        return {"status": "setup_required", "message": "Setup required"}
    
    # Check if admin user exists
    try:
        user_count = await db.users.count_documents({})
        if user_count == 0:
             return {"status": "setup_required", "message": "Create admin account"}
    except Exception:
        return {"status": "db_error", "message": "Database error"}

    return {"status": "ok", "message": "System operational"}

@api_router.post("/setup")
async def run_setup(data: SetupData):
    global mongo_client, db, JWT_SECRET
    
    # 1. Verify connection
    try:
        temp_client = AsyncIOMotorClient(data.mongo_url, serverSelectionTimeoutMS=5000)
        await temp_client.server_info()
        temp_client.close()
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Cannot connect to MongoDB: {str(e)}")

    # 2. Write .env file
    env_content = f"""MONGO_URL={data.mongo_url}
DB_NAME={data.db_name}
JWT_SECRET={uuid.uuid4().hex}
RESEND_API_KEY=
SENDER_EMAIL=onboarding@resend.dev
"""
    try:
        with open(ENV_PATH, "w") as f:
            f.write(env_content)
        # Reload env
        os.environ['MONGO_URL'] = data.mongo_url
        os.environ['DB_NAME'] = data.db_name
        # Reload JWT Secret too as we regenerated it
        load_dotenv(ENV_PATH, override=True)
        JWT_SECRET = os.environ.get('JWT_SECRET')
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to write configuration: {str(e)}")

    # 3. Connect global client
    if not await connect_db():
        raise HTTPException(status_code=500, detail="Failed to connect to database after configuration")

    # 4. Create Admin User
    try:
        # Check if users already exist (in case of re-setup on existing db)
        user_count = await db.users.count_documents({})
        role = "admin" # Force admin for setup
        
        # Hash password (using the helper function defined later, so we grab it or move it up)
        # Moving helpers up or defining locally for now to avoid reordering connection chaos
        pwd_hash = bcrypt.hashpw(data.admin_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        
        user = User(
            email=data.admin_email,
            name=data.admin_name,
            role=role,
            id=str(uuid.uuid4()),
            created_at=datetime.now(timezone.utc).isoformat()
        )
        user_doc = user.model_dump()
        user_doc["password_hash"] = pwd_hash
        
        # Upsert user by email to avoid duplicates if re-running
        await db.users.update_one(
            {"email": data.admin_email}, 
            {"$set": user_doc}, 
            upsert=True
        )
        
        # Create default settings if needed
        default_settings = AppSettings()
        await db.settings.update_one(
            {"id": "app_settings"},
            {"$setOnInsert": default_settings.model_dump()},
            upsert=True
        )
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create admin user: {str(e)}")

    return {"message": "Setup completed successfully"}
