
import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

async def check_categories():
    load_dotenv('backend/.env')
    mongo_url = os.getenv('MONGO_URL')
    db_name = os.getenv('DB_NAME', 'service_renewal_hub')
    
    if not mongo_url:
        print("MONGO_URL not found in .env")
        return

    print(f"Connecting to {mongo_url}, DB: {db_name}")
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    cats = await db.categories.find().to_list(100)
    print(f"Total categories: {len(cats)}")
    for c in cats:
        print(f"Category: {c.get('name')} (ID: {c.get('id')}, UserID: {c.get('user_id')})")
    
    users = await db.users.find().to_list(100)
    print(f"\nTotal users: {len(users)}")
    for u in users:
        print(f"User: {u.get('email')} (ID: {u.get('id')})")
        
    client.close()

if __name__ == "__main__":
    asyncio.run(check_categories())
